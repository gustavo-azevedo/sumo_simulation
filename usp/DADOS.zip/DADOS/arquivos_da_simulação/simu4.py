import os, sys
import optparse
import subprocess
import random
import math
import numpy as np
import pandas as pd


# we need to import python modules from the $SUMO_HOME/tools directory
try:
    sys.path.append("/home/gustavo/Downloads/sumo-1.3.1/tools")
    from sumolib import checkBinary
except ImportError:
    sys.exit("please declare environment variable 'SUMO_HOME' as the root directory of your sumo installation (it should contain folders 'bin', 'tools' and 'docs')")       
import traci

#functions to calculate the distance between 2 cars

def get_options():
    opt_parser = optparse.OptionParser()
    opt_parser.add_option("--nogui", action="store_true",
                         default=False, help="run the commandline version of sumo")
    options, args = opt_parser.parse_args()
    return options

def binarySearch(arr,l,r,x):
    if r >= l:
        mid = l + (r - l)//2
        if arr[mid] == x:
            return 1
        elif arr[mid] > x:
            return binarySearch(arr,l,mid-1,x)
        else:
            return binarySearch(arr,mid+1,r,x)
    else:
        return 0

def pos_x(x):
    pos_x = traci.vehicle.getPosition(x)[0]
    return pos_x

def pos_y(x):
    pos_y = traci.vehicle.getPosition(x)[1]
    return pos_y

def prob(probability):     #returns true or false based on the probability given of beeing true
    return random.random() < probability

def contamination(sender,receiver,data_msgs): #pass on the contaminated colors to the non-contaminated cars
    name_of_sender = str(sender)
    name_of_receiver = str(receiver)
    name_of_message = str(sender) + ':' + str(receiver) #creates the name of the row in which the messages are stored
    vetor = data_msgs['name'] == name_of_message
    found_array = np.array(vetor)
    found = np.count_nonzero(found_array == 1)
    if found:
        n_msgs = len(data_msgs.columns) - 3 #number of messages doesn't count the name column
        i=0
        j=0
        cont = True #variable continue
        if data_msgs['msg' + str(n_msgs)][list(data_msgs['name']).index(name_of_message)] != 2: #it stops the messages from going more than the number established
            cont==False
        while j < n_msgs and cont == True: #iterate the columns
            if data_msgs['msg' + str(j + 1)][list(data_msgs['name']).index(name_of_message)]==2:
                threshold = 0.2
                msg = random.random()
                if msg > threshold:
                    data_msgs.loc[data_msgs.name==name_of_message,'msg' + str(j + 1)] = prob(random.random())
                else:
                    data_msgs.loc[data_msgs.name==name_of_message,'msg' + str(j + 1)] = False
                cont = False
            else:
                j += 1
        j=0
    else:
        n_msgs = len(data_msgs.columns) - 3
        dic_add = {'name' : name_of_message,
                   'sender' : name_of_sender,
                   'receiver' : name_of_receiver}
        for i in range(n_msgs):
            dic_add['msg' + str(i + 1)] = 2
        msg = random.random()
        threshold = 0.2
        if msg > threshold:
            dic_add['msg1'] = prob(msg)
        else:
            dic_add['msg1'] = False
        data_msgs = data_msgs.append(dic_add,ignore_index=True)
    return data_msgs


# contains TraCI control loop
def run():
    step = 0
    iterator = 0
    number_of_messages = input("Choose the number of messages: ")
    beginning = {'name' : 'name_of_message',
                 'sender' : 'beginning',
                 'receiver' : 'end'}
    number_of_messages = int(number_of_messages)
    for iterator in range(number_of_messages):
        beginning['msg' + str(iterator + 1)] = [prob(random.random())]
    data_msgs = pd.DataFrame(beginning)
    while traci.simulation.getMinExpectedNumber() > 0:
        traci.simulationStep()
        step += 1  
        if step > 2 and step < 250:

            car_vector = traci.vehicle.getIDList() # actualizes the list of cars
            
            for i in car_vector: #reroutes cars so they dont get out of the simulation
                if traci.vehicle.getRouteIndex(str(i)) == (len(traci.vehicle.getRoute(str(i))) - 1): #verification to see if the car is at the end of its route
                    new_destiny = random.choice(traci.edge.getIDList())
                    while (new_destiny[0] == ':'):
                        new_destiny = random.choice(traci.edge.getIDList())
                    traci.vehicle.changeTarget(str(i),str(new_destiny))
            
            senders = random.sample(car_vector,k=np.random.randint(0,high=int(len(car_vector))))  #it gives some time for the cars to enter the simulation
            
            pos_vector_x = np.array(list(map(pos_x,car_vector))) #gets position of all the cars in the simulation
            pos_vector_y = np.array(list(map(pos_y,car_vector)))
            

            for sender in senders: #the messages are sent
                dist = np.sqrt((pos_vector_x - traci.vehicle.getPosition(sender)[0])**2 + (pos_vector_y - traci.vehicle.getPosition(sender)[1])**2)
                for j , receiver in enumerate(dist):
                    if receiver < 30 and receiver > 0.5:
                        data_msgs = contamination(sender,car_vector[j],data_msgs)
            print(data_msgs.head(100))
        
        if step == 250:
            data_msgs.set_index('name',inplace=True)
            data_msgs = data_msgs.drop('name_of_message')
            export_csv = data_msgs.to_csv(r'/home/gustavo/Desktop/Usp/teste.csv', index = None, header=True)
    traci.close()
    sys.stdout.flush()

# main entry point
if __name__ == "__main__":
    options = get_options()

    # check binary
    if options.nogui:
        sumoBinary = checkBinary('sumo')
    else:
        sumoBinary = checkBinary('sumo-gui')

    # traci starts sumo as a subprocess and then this script connects and runs
    traci.start([sumoBinary, "-c", "usp.sumocfg",
                             "--tripinfo-output", "tripinfo.xml"])
    run()